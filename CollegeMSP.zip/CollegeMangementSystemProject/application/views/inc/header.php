<html lang="en">
<head>
		<meta charset="utf-8">
		<title>College Management System</title>
		<link rel="stylesheet" href="<?php echo base_url('Assets/css/bootstrap.css'); ?>"/>
		<script src="<?php echo base_url('Assets/js/jquery-3.1.0.js'); ?>"></script>
		<script src="<?php echo base_url('Assets/js/bootstrap.js'); ?>"></script>
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <a class="navbar-brand" href="#">COLLEGE MANAGEMENT SYSTEM</a>
</nav>
